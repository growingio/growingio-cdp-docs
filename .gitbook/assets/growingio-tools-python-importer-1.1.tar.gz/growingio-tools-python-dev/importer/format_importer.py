#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved
import argparse
import os
import pathlib
import sys
import logging

sys.path.append(str(pathlib.Path(os.path.abspath(__file__)).parent.parent))

from importer.common.log_util import logger
from importer.common.sqlalchemy_util import get_tunnel_id_by_key
from importer.db_import.mysql_import import events, user_variables
from importer.meta.meta_create import *


def parse_args():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-m',
                        help='必填参数. 事件events，用户属性user_variables',
                        required=True,
                        metavar="")
    parser.add_argument('-ds', '--datasource_id', help='必填参数. 接收导入数据的数据源ID', required=True, metavar="")
    parser.add_argument('-f', '--format', help='必填参数. 导入格式，填写mysql', required=True, metavar="")
    parser.add_argument('-db_host', '--db_host', help='必填参数. 客户数据源地址', required=True, metavar="")
    parser.add_argument('-db_user', '--db_user', help='必填参数. 客户数据源用户', required=True, metavar="")
    parser.add_argument('-db_password', '--db_password', help='必填参数. 客户数据源密码', required=True, metavar="")
    parser.add_argument('-db_port', '--db_port', help='可选参数. 客户数据源端口', default=3306, metavar="")
    parser.add_argument('-sql', '--sql', help='必选参数. sql语句', required=True, metavar="")
    parser.add_argument('-s', '--start_time', help='用户行为数据必选参数. 开始时间', metavar="")
    parser.add_argument('-e', '--end_time', help='用户行为数据必选参数. 结束时间', metavar="")
    args = parser.parse_args()
    return args.__dict__


def main():
    args = parse_args()
    ds = get_tunnel_id_by_key(args.get('datasource_id'))
    if ds is None:
        logger.error("数据源不存在")
        exit(-1)
    m = args.get("m")
    args['datasource_id'] = ds
    if 'events'.__eq__(m):
        events(args)
    elif 'user_variables'.__eq__(m):
        user_variables(args)
    else:
        logging.error("请确认填写项目名！")
        exit(-1)


if __name__ == '__main__':
    main()
