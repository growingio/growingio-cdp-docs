#!/bin/env python3
# -*- coding: UTF-8 -*-

import requests
import json
from importer.common.config_util import ApiConfig


def get_token():
    """登录获取身份令牌"""

    payload = {'grant_type': ApiConfig.grant_type, 'client_id': ApiConfig.oauth2_client_id,
               'client_secret': ApiConfig.oauth2_client_secret, 'scope': ApiConfig.scope}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(ApiConfig.oauth2_uri + "/oauth/access_token", headers=headers, data=payload)
    content = json.loads(response.content)
    return content['access_token']


# graphql post请求
def send_graphql_post(token, body):
    headers = {'Content-Type': 'application/json', 'Authorization': token}
    r = requests.post(ApiConfig.oauth2_uri + "/graphql", headers=headers, data=body)
    content = json.loads(r.content)
    return content['data']
