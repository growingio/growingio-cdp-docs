import io
import pandas as pd
import numpy as np
import os
import shutil
import pymysql
import pytz
import datetime
import time

from hashids import Hashids
from importer.common.config_util import CommConfig, BaseConfig

hashids = Hashids(salt=CommConfig.comm_salt, min_length=8)


# 加密
def encode(id):
    return hashids.encode(id)


# 解密
def decode(str):
    return hashids.decode(str)[0]


def split_str(s, sep, qualifier):
    """
    分割复杂字符串
     例如：'"sss,ss", userId,event,tismestamp,,"sss,ss",tismes,"sss,ss"'
     结果：['sss,ss', 'userId', 'event', 'tismestamp', '', 'sss,ss', 'tismes', 'sss,ss']
    :param s: 字符串
    :param sep: 分隔符
    :param qualifier: 文本限定符
    :return: List
    """
    if s is None or s.strip() is '':
        return []
    df = pd.read_csv(io.StringIO(s), sep=sep, quotechar=qualifier, header=None, na_filter=False)
    return np.array(df.where(df.notnull(), '')).tolist()[0]


def get_all_file(path):
    """
    获取目录下全部文件，包含子文件下的
    :param path: 目录或文件路径
    :return: [file_abs_path1,file_abs_path2,...]
    """
    res = []
    if os.path.isdir(path):
        for root, dirs, files in os.walk(path, topdown=False):
            for name in files:
                res.append(os.path.join(root, name))
    else:
        res.append(path)
    return res


def remove_file(path):
    """
     删除Path.如果是文件路径直接删除文件；如果是目录，删除目录及目录下全部
    :param path: 目录或文件
    """
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)
    else:
        os.rmdir(path)


def create_dir(dir_str):
    """
     创建目录
    :param dir_str: 目录
    """
    if os.path.exists(dir_str) is False:
        os.makedirs(dir_str)


def time_str_to_timestamp_of_tz(time_str, format, timezone):
    """
     时间字符串转时间戳，带时区
    :param time_str:
    :param format:
    :param timezone:
    :return:
    """
    tz = pytz.timezone(timezone)
    dt = datetime.datetime.strptime(time_str, format)
    t = tz.localize(dt).astimezone(pytz.utc)
    return int(time.mktime(t.utctimetuple())) - time.timezone


def mysql_connect(user, password, host, port):
    return pymysql.connect(
        host=host,
        port=port,
        user=user,
        charset='utf8',
        passwd=password,
        db=db
    )
