#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved

import time
import json
import tempfile
import os

from importer.data_import.data_model import UserVariablesSv, UserVariablesJson, DataUser
from importer.data_import.data_format_util import *
from importer.common import sqlalchemy_util, http_util, common_util
from importer.common.common_util import encode, get_all_file, remove_file
from importer.common.log_util import logger
from json.decoder import JSONDecodeError


def user_variables_import(args):
    """
       用户属性导入，按数据格式处理
    """
    # Step one: 校验事件数据基础参数，并预处理
    # 1. 数据源是否为属性
    ds = args.get('datasource_id')
    if 'USER_PROPERTY'.__eq__(ds[1]['type']):
        args['datasource_id'] = encode(ds[0])
    else:
        logger.error("数据源不属于用户属性类型")
        return
    # Step one: 按数据格式处理
    f = str(args.get('format'))
    if 'JSON'.__eq__(f):
        user_variables_import_json(
            UserVariablesJson(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                              datasourceId=args.get('datasource_id'))
        )
    elif 'CSV'.__eq__(f):
        user_variables_import_sv(
            UserVariablesSv(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                            datasourceId=args.get('datasource_id'), attributes=args.get('attributes'), separator=",",
                            skipHeader=args.get('skip_header'))
        )
    elif 'TSV'.__eq__(f):
        user_variables_import_sv(
            UserVariablesSv(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                            datasourceId=args.get('datasource_id'), attributes=args.get('attributes'), separator='\t',
                            skipHeader=args.get('skip_header'))
        )


def user_variables_import_sv(userVariablesSv):
    """
       用户属性导入，CSV/TSV格式数据处理
    """
    # Step 1: 创建临时文件夹，用于存储临时Json文件
    current_tmp_path = tempfile.gettempdir() + '/' + str(int(round(time.time() * 1000)))
    if os.path.exists(current_tmp_path) is False:
        os.makedirs(current_tmp_path)
    logger.debug(f"临时存储Json文件目录：[{current_tmp_path}]")
    try:
        # Step 2: 校验SV数据，并转为为Json个数
        n = 0
        for path in userVariablesSv.path:
            json_file_abs_path = current_tmp_path + '/' + os.path.basename(path).split('.')[0] + '.json'
            res = sv_import_prepare_process(attributes=userVariablesSv.attributes,
                                            path=path,
                                            skip_header=userVariablesSv.skipHeader,
                                            separator=userVariablesSv.separator,
                                            qualifier=userVariablesSv.qualifier,
                                            json_file_abs_path=json_file_abs_path)
            if res:
                n = n + 1
        # Step 3: 调用Json导入函数:user_variables_import_json
        if n == len(userVariablesSv.path):
            user_variables_import_json(
                UserVariablesJson(name='user_variables',
                                  path=get_all_file(current_tmp_path),
                                  debug=userVariablesSv.debug,
                                  format='JSON',
                                  datasourceId=userVariablesSv.datasourceId)
                )
    finally:
        # Step 4: 清理Json临时文件
        remove_file(current_tmp_path)


# SV格式(CSV、TSV)
def sv_import_prepare_process(attributes, path, skip_header, separator, qualifier, json_file_abs_path):
    """
      1.校验数据基本信息
      2.SV格式数据转换为Json格式导入
    """
    # Step 1: 校验有无attributes,有无重复列名
    if attributes is None:
        logger.error("[-attr/--attributes]参数值不存在")
        return
    cols = str(attributes).split(',')
    duplicate_col = check_sv_col_duplicate(cols)
    if duplicate_col is not None:
        logger.error(f"[-attr/--attributes]出现重复列值[{duplicate_col}]")
        return
    keys = sqlalchemy_util.get_user_variables_activated_key()
    with open(path, 'r', encoding='utf8') as f:
        with open(json_file_abs_path, 'w') as wf:
            line = f.readline().replace('\n', '').replace('\\t', '\t')
            # Step 2: 校验数据header列是否一致，数量和顺序
            if skip_header is True:
                if check_sv_header_col_count(cols, line.split(separator)) is False:
                    logger.error(f"[-attr/--attributes]参数值列与导入文件[{path}]的列数不一致")
                    return
                if check_sv_header_col_order(cols, line.split(separator)) is False:
                    logger.error(f"[-attr/--attributes]参数值列与导入文件[{path}]的列顺序不一致")
                    return
                line = f.readline().replace('\n', '').replace('\\t', '\t')
            # Step 3: 校验数据列是否一致
            while line != '':
                values = common_util.split_str(line, separator, qualifier)
                if len(cols) != len(values):
                    logger.error(f"文件[{path}]数据[{line}]列数与文件头部列数不一致")
                    return
                # Step 4: 转换为JSON格式
                col_value = {}
                for col, value in tuple(zip(cols, values)):
                    if col != '':
                        col_value[col] = value
                attrs = {}
                for key in col_value:
                    if key.startswith('$') is False and key not in keys \
                                                    and 'userId'.__eq__(key) is False:
                        logger.error(f"文件[{path}]数据[{line}]用户属性[{key}]在GIO平台未定义")
                        return
                    elif 'userId'.__eq__(key) is False:
                        attrs[key] = col_value[key]
                data_event = DataUser(userId=col_value['userId'], attrs=attrs)
                wf.write(json.dumps(data_event.__dict__, ensure_ascii=False))
                wf.write('\n')
                line = f.readline().replace('\n', '').replace('\\t', '\t')
    return True


def user_variables_import_json(userVariablesJson):
    """
       用户属性导入，Json格式数据处理
    """
    # Step 1: 执行Debug
    if userVariablesJson.debug:
        if user_variables_debug_process(userVariablesJson.path) is not True:
            logger.error("Debug校验未通过")
            return
    # Step 2: 创建导入任务
    job_info = create_task(userVariablesJson.datasourceId)
    logger.info(f"创建导入任务: {job_info}")
    # Step 3: 上传数据到FTP
    put_file(userVariablesJson.path, job_info['argument']['directory'])
    # Step 4: 启动导入任务
    trigger_job(job_info['id'])


def trigger_job(id):
    body = '''{
      "operationName":"executeJob",
      "variables":{"id":"%s"},
      "query":"mutation executeJob($id: HashId!) {  
        executeJob(id: $id) {
            id    
            stage    
            __typename  
        }
      }"
    }''' % id
    http_util.send_graphql_post(http_util.get_token(), body)


def create_task(ds):
    body = '''{
      "operationName": "createEventImportJob",
      "variables": {
        "tunnelId": "%s",
        "timeRange": ""
      },
      "query": "mutation createEventImportJob($tunnelId: HashId!, $timeRange: String) {
        createEventImportJob(tunnelId: $tunnelId, timeRange: $timeRange) {
          id
          name
          argument {
            directory
            __typename
          }
          __typename
        }
      }"
    }''' % ds
    resp = http_util.send_graphql_post(http_util.get_token(), body)
    return resp['createEventImportJob']


def user_variables_debug_process(paths):
    """
       用户属性导入Debug
       1、校验有无userId
       2、校验用户属性(条件:是否是平台内置和是否定义)
    """
    keys = sqlalchemy_util.get_user_variables_activated_key()
    count = 0
    for path in paths:
        with open(path, 'r', encoding='utf8') as f:
            line = f.readline().replace('\n', '')
            while line.strip() != '':
                count = count + 1
                try:
                    j_dict = json.loads(line)
                    # userId
                    if 'userId' not in j_dict:
                        logger.error(f"文件[{path}]数据[{line}]userId不存在")
                        return
                    # 用户属性
                    if isinstance(j_dict['attrs'], dict) is False:
                        logger.error(f"文件[{path}]数据[{line}]attrs数据格式不对")
                        return
                    for key in j_dict['attrs']:
                        if j_dict['attrs'][key] is None:
                            logger.error(f"文件[{path}]数据[{line}], 用户属性[{key}]的值为NULL,请检查原始数据")
                            return
                        if key.startswith('$') is False and key not in keys:
                            logger.error(f"文件[{path}]数据[{line}], 用户属性[{key}]在GIO平台未定义")
                            return
                except JSONDecodeError:
                    logger.error(f"文件[{path}]数据[{line}]非JSON格式")
                    return
                line = f.readline().replace('\n', '')
    logger.info(f"本次共导入[{count}]行数据")
    return True
