import json

from importer.common.http_util import send_graphql_post, get_token
from importer.meta.check_util import *
from importer.meta.data_center import getMetaData, getBindEvent

"""
元数据创建
"""


# 创建事件
def create_event(token, key, name, desc):
    name = check_name(name, key)
    flag, var = check_event_exsit(token, key)
    if flag:
        if desc == '':
            body = """{"operationName":"updateDataCenterCustomEvent","variables":{"id":"%s","customEvent":{"name":"%s","key":"%s","description":"%s",
            "valueType":"counter","attributes":[],"itemModels":[]}},"query":"mutation updateDataCenterCustomEvent($id: HashId!, $customEvent: CustomEventInput!) 
            {  updateDataCenterCustomEvent(id: $id, customEvent: $customEvent) {    name    __typename  }}"}""" % (
                var['id'], name, key, var['description'])
        elif name == key:
            body = """{"operationName":"updateDataCenterCustomEvent","variables":{"id":"%s","customEvent":{"name":"%s","key":"%s","description":"%s",
              "valueType":"counter","attributes":[],"itemModels":[]}},"query":"mutation updateDataCenterCustomEvent($id: HashId!, $customEvent: CustomEventInput!) 
             {  updateDataCenterCustomEvent(id: $id, customEvent: $customEvent) {    name    __typename  }}"}""" % (
                var['id'], var['name'], key, desc)
        else:
            body = """{"operationName":"updateDataCenterCustomEvent","variables":{"id":"%s","customEvent":{"name":"%s","key":"%s","description":"%s",
             "valueType":"counter","attributes":[],"itemModels":[]}},"query":"mutation updateDataCenterCustomEvent($id: HashId!, $customEvent: CustomEventInput!) 
             {  updateDataCenterCustomEvent(id: $id, customEvent: $customEvent) {    name    __typename  }}"}""" % (
                var['id'], name, key, desc)
    else:
        body = """{"operationName":"createDataCenterCustomEvent","variables":{"customEvent":{"name":"%s","key":"%s","valueType":"counter",
            "description":"%s","attributes":[],"itemModels":[]}},"query":"mutation createDataCenterCustomEvent($customEvent: CustomEventInput!) 
            {createDataCenterCustomEvent(customEvent: $customEvent) {name    __typename}}"}""" % (name, key, desc)
    content = send_graphql_post(token, body.encode('utf-8'))
    return content


# 创建事件属性
def create_event_variables(token, key, valuetype, name, desc):
    name = check_name(name, key)
    check_event_valuetype(valuetype)
    flag, var = check_event_var_exsit(token, key)
    if flag:
        if desc == '':
            body = """{"operationName":"updateDataCenterEventVariable","variables":{"id":"%s","eventVariable":{"name":"%s","key":"%s",
                    "description":"%s","valueType":"%s"}},"query":"mutation updateDataCenterEventVariable($id: HashId!, $eventVariable: VariableInput!) 
                    {  updateDataCenterEventVariable(id: $id, eventVariable: $eventVariable) {    name    __typename  }}"}""" % (
                var['id'], name, key, var['description'], var['valueType'])
        elif name == key:
            body = """{"operationName":"updateDataCenterEventVariable","variables":{"id":"%s","eventVariable":{"name":"%s","key":"%s",
                     "description":"%s","valueType":"%s"}},"query":"mutation updateDataCenterEventVariable($id: HashId!, $eventVariable: VariableInput!) 
                     {  updateDataCenterEventVariable(id: $id, eventVariable: $eventVariable) {    name    __typename  }}"}""" % (
                var['id'], var['name'], key, desc, var['valueType'])
        else:
            body = """{"operationName":"updateDataCenterEventVariable","variables":{"id":"%s","eventVariable":{"name":"%s","key":"%s",
                     "description":"%s","valueType":"%s"}},"query":"mutation updateDataCenterEventVariable($id: HashId!, $eventVariable: VariableInput!) 
                     {  updateDataCenterEventVariable(id: $id, eventVariable: $eventVariable) {    name    __typename  }}"}""" % (
                var['id'], name, key, desc, var['valueType'])
        content = send_graphql_post(token, body.encode('utf-8'))
        print("事件属性存在且更新成功")
    else:
        body = """{"operationName":"createDataCenterEventVariable","variables":{"eventVariable":{"name":"%s","key":"%s",
        "valueType":"%s","description":"%s"}},"query":"mutation createDataCenterEventVariable($eventVariable: VariableInput!) 
        {createDataCenterEventVariable(eventVariable: $eventVariable) {name    __typename}}"}""" % (
            name, key, valuetype, desc)
        content = send_graphql_post(token, body.encode('utf-8'))
    return content


# 创建用户属性
def create_user_variables(token, key, valuetype, name, desc):
    name = check_name(name, key)
    check_user_valuetype(valuetype)
    flag, var = check_user_var_exsit(token, key)
    if flag:
        if desc == '':
            body = """{"operationName":"updateDataCenterUserVariable","variables":{"id":"%s","userVariable":{"name":"%s","key":"%s","description":"%s",
            "valueType":"%s"}},"query":"mutation updateDataCenterUserVariable($id: HashId!, $userVariable: VariableInput!) {  updateDataCenterUserVariable(id: $id,
             userVariable: $userVariable) {    name    __typename  }}"}""" % (
                var['id'], name, key, var['description'], var['valueType'])
        elif name == key:
            body = """{"operationName":"updateDataCenterUserVariable","variables":{"id":"%s","userVariable":{"name":"%s","key":"%s","description":"%s",
             "valueType":"%s"}},"query":"mutation updateDataCenterUserVariable($id: HashId!, $userVariable: VariableInput!) {  updateDataCenterUserVariable(id: $id,
             userVariable: $userVariable) {    name    __typename  }}"}""" % (
                var['id'], var['name'], key, desc, var['valueType'])
        else:
            body = """{"operationName":"updateDataCenterUserVariable","variables":{"id":"%s","userVariable":{"name":"%s","key":"%s","description":"%s",
            "valueType":"%s"}},"query":"mutation updateDataCenterUserVariable($id: HashId!, $userVariable: VariableInput!) {  updateDataCenterUserVariable(id: $id,
            userVariable: $userVariable) {    name    __typename  }}"}""" % (
                var['id'], name, key, desc, var['valueType'])
        content = send_graphql_post(token, body.encode('utf-8'))
        print("用户属性存在且更新成功")
    else:
        body = """{"operationName":"createDataCenterUserVariable","variables":{"userVariable":{"name":"%s","key":"%s","valueType":"%s","description":"%s"}},
        "query":"mutation createDataCenterUserVariable($userVariable: VariableInput!) {createDataCenterUserVariable(userVariable: $userVariable) {
            id    name    __typename  }}"}""" % (name, key, valuetype, desc)
        content = send_graphql_post(token, body.encode('utf-8'))
    return content


# 绑定事件与事件属性
def bind_event_variables(token, key, name, attr):
    name = check_name(name, key)
    flag, event_id, desc = check_bind_event_exsit(token, key)
    id_list, key_list = check_attr(token, attr)
    attr_str = ''
    size = len(id_list)
    for i in range(size):
        attr_str += '{\"id\":\"' + str(id_list[i]) + '\"},'
    str_sub = attr_str[:len(attr_str) - 1]
    if flag:
        body = """{"operationName":"updateDataCenterCustomEvent","variables":{"id":"%s","customEvent":{"name":"%s","key":"%s","description":"%s","valueType":"counter",
                    "attributes":[%s],"itemModels":[]}},"query":"mutation updateDataCenterCustomEvent($id: HashId!, $customEvent: CustomEventInput!) 
                    {  updateDataCenterCustomEvent(id: $id, customEvent: $customEvent) {    name    __typename  }}"}""" % (
            event_id, name, key, desc, str_sub)
    else:
        body = """{"operationName":"createDataCenterCustomEvent","variables":{"customEvent":{"name":"%s","key":"%s","valueType":"counter",
        "attributes":[%s],"itemModels":[]}},"query":"mutation createDataCenterCustomEvent($customEvent:
        CustomEventInput!) {createDataCenterCustomEvent(customEvent: $customEvent) {name    __typename  }}"}""" % (
            name, key, str_sub)
    content = send_graphql_post(token, body.encode('utf-8'))
    return content, key_list


# 导出元数据
def export_meta(token, file):
    meta_data = getMetaData(token)
    meta_data['events'] = meta_data.pop('dataCenterCustomEvents')
    meta_data['event_variables'] = meta_data.pop('dataCenterEventVariables')
    meta_data['user_variables'] = meta_data.pop('dataCenterUserVariables')
    meta_data = str(meta_data).replace('\'', '\"')[:-1]

    event = getBindEvent(token)
    event['bind_event_variables'] = event.pop('dataCenterCustomEvents')
    event = str(event).replace('\'', '\"')[1:]
    json_str = meta_data + ',' + event
    with open(file, "w") as f:
        json.dump(json.loads(json_str), f)
    print("导出元数据成功~")


# 导入元数据
def import_meta(token, file):
    with open(file, 'r', encoding='utf-8') as f:
        json_loads = json.loads(f.read())
        for event in json_loads['events']:
            check_key(event['key'])
            create_event(token, event['key'], event['name'], event['description'])
        for var in json_loads['event_variables']:
            check_key(var['key'])
            create_event_variables(token, var['key'], var['valueType'], var['name'], var['description'])
        for var in json_loads['user_variables']:
            check_key(var['key'])
            create_user_variables(token, var['key'], var['valueType'], var['name'], var['description'])
        for var in json_loads['bind_event_variables']:
            attr_str = ''
            for attr in var['attributes']:
                attr_str += str(attr['key']) + ','
            sub_attr = attr_str[:-1]
            bind_event_variables(token, var['key'], '', sub_attr)
    print("导入元数据成功~")
