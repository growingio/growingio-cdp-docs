import json

from importer.common.http_util import send_graphql_post, get_token


# 获取custom_events表(id,key,name,description)数据
def getdataCenterCustomEvents(token=get_token()):
    """
        获取 CustomEvents (id,key,name,description)
    """
    body = """{"query":"query MyQuery {  dataCenterCustomEvents {    id   key   name   description}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterCustomEvents']
    return data_info

def getdataCenterCustomEventsAndAttr(token=get_token()):
    """
        获取 CustomEvents (id,key,name,description,attributes(id,key))
    """
    body = """{"query":"query MyQuery {  dataCenterCustomEvents {    id   key   name   description   attributes {id  key}}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterCustomEvents']
    return data_info


def getdataCenterUserVariables(token=get_token()):
    """
        获取 UserVariables (id,key,name,description,valueType)
    """
    body = """{"query":"query MyQuery {  dataCenterUserVariables {    id   key   name   description   valueType}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterUserVariables']
    return data_info


def getdataCenterEventVariables(token=get_token()):
    """
        获取 EventVariables (id,key,name,description,valueType)
    """
    body = """{"query":"query MyQuery {dataCenterEventVariables {    id   key   name   description   valueType}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterEventVariables']
    return data_info


# 获取元数据
def getMetaData(token=get_token()):
    """
        获取元数据
    """
    body = """{"query":"query MyQuery {dataCenterCustomEvents {    key    name    description  }  dataCenterEventVariables {    key    name    
    valueType    description  }  dataCenterUserVariables {    key    name    valueType    description  }}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content
    return data_info


def getBindEvent(token=get_token()):
    """
        获取绑定事件和关联事件属性
    """
    body = """{"query":"query MyQuery {  dataCenterCustomEvents {    key    attributes {      key    }  }}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content
    return data_info


def getTunnels(token=get_token()):
    """
        获取 tunnels(id  key   type   config {   ... on FileTunnelConfig {  type   } })
    """
    body = """{"query":"query MyQuery {  tunnels {id  key   type   config {   ... on FileTunnelConfig {  type   } } }}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    tunnels = content['tunnels']
    t_res = {}
    for t in tunnels:
        res = {}
        if t['type'] == 'FILE':
            res[t['config']['type']] = t['id']
            t_res[t['key']] = res
    return t_res
