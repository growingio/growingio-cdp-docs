#!/bin/env python3
# -*- coding: UTF-8 -*-

import requests
import json
import logging
from importer.common.config_util import ApiConfig


def get_token():
    """登录获取身份令牌"""
    payload = {'grant_type': ApiConfig.grant_type, 'client_id': ApiConfig.oauth2_client_id,
               'client_secret': ApiConfig.oauth2_client_secret, 'scope': ApiConfig.scope}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(ApiConfig.oauth2_uri + "/oauth/access_token", headers=headers, data=payload)
    if response.status_code == 200:
        content = json.loads(response.content)
        return content['access_token']
    else:
        logging.error("获取登录身份令牌失败，请检查配置{}".format(payload))
        exit(-1)


# graphql post请求
def send_graphql_post(token, body):
    headers = {'Content-Type': 'application/json', 'Authorization': token}
    r = requests.post(ApiConfig.oauth2_uri + "/graphql", headers=headers, data=body)
    if r.status_code == 200:
        content = json.loads(r.content)
        if content.keys().__contains__("data") is True:
            return content['data']
        else:
            logging.error('Graphql请求错误,{}'.format(content['errors']))
            exit(-1)
    else:
        re = input("Graphql请求超时或失败，是否重新请求，请输入yes/no:")
        if str(re).lower() == 'yes':
            send_graphql_post(token, body)
        else:
            return
