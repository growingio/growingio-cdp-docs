import json
import os
import tempfile
import time

from importer.common.common_util import encode, time_str_to_timestamp_of_tz
from importer.common.config_util import BaseConfig
from importer.common.log_util import logger
from importer.data_import.data_events import ONE_DAY_MILLISECOND, events_import_json
from importer.db_import.hive_import import event_hive_import, user_hive_import
from importer.db_import.mysql_import import event_mysql_import, user_mysql_import


def events(args):
    try:
        start = time_str_to_timestamp_of_tz(args.get('start_time'), '%Y-%m-%d', BaseConfig.timezone) * 1000
        end = time_str_to_timestamp_of_tz(args.get('end_time'), '%Y-%m-%d',
                                          BaseConfig.timezone) * 1000 + ONE_DAY_MILLISECOND
    except TypeError and ValueError:
        logger.error("[-s/--start_time]或[-e/--end_time]时间参数格式不对,格式为:YYYY-MM-DD")
        exit(-1)
    ds = args.get('datasource_id')
    if 'HISTORY_EVENT'.__eq__(ds[1]['type']):
        args['datasource_id'] = encode(ds[0])
    else:
        logger.error("数据源不属于用户行为类型")
        exit(-1)
    f = args.get('format')
    if 'MYSQL'.__eq__(str(f).upper()):
        event_mysql_import(args, start, end)
    elif 'HIVE'.__eq__(str(f).upper()):
        event_hive_import(args, start, end)
    else:
        logger.error("format不在取值范围内")
        exit(-1)


def user_variables(args):
    ds = args.get('datasource_id')
    if 'USER_PROPERTY'.__eq__(ds[1]['type']):
        args['datasource_id'] = encode(ds[0])
    else:
        logger.error("数据源不属于用户属性类型")
        exit(-1)
    if 'MYSQL'.__eq__(str(args.get('format')).upper()):
        user_mysql_import(args)
    elif 'HIVE'.__eq__(str(args.get('format')).upper()):
        user_hive_import(args)
    else:
        logger.error("format不在取值范围内")
        exit(-1)
