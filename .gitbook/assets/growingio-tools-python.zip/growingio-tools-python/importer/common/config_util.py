#!/bin/env python3
# -*- coding: UTF-8 -*-

import os
import pathlib
from configparser import ConfigParser

config = ConfigParser()
config.read(os.path.abspath(str(pathlib.Path(os.path.abspath(__file__)).parent.parent) + "/conf.cfg"), encoding="UTF-8")


class DatabaseConfig:
    """A ApiConfig Class"""
    conn_events = config['DATABASE']['sql_alchemy_conn_events']
    conn_cdp = config['DATABASE']['sql_alchemy_conn_cdp']


class ApiConfig:
    """A ApiConfig Class"""
    oauth2_uri = config['API']['oauth2_uri']
    oauth2_client_id = config['API']['oauth2_client_id']
    oauth2_client_secret = config['API']['oauth2_client_secret']
    grant_type = config['API']['grant_type']
    scope = config['API']['scope']


class BaseConfig:
    """A BaseConfig Class"""
    account_id = config['BASE']['timezone']
    account_id = config['BASE']['account_id']


class CommConfig:
    comm_salt = config['COMMON']['comm_salt']


class FTPConfig:
    host = config['FTP']['ftp_host']
    user = config['FTP']['ftp_user']
    password = config['FTP']['ftp_password']
    port = config['FTP']['ftp_port']
