import json

from importer.common.http_util import send_graphql_post, get_token


# 获取custom_events表(id,key,name,description)数据
def getdataCenterCustomEvents(token=get_token()):
    body = """{"query":"query MyQuery {  dataCenterCustomEvents {    id   key   name   description}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterCustomEvents']
    return data_info


# 获取user_variables表(id,key,name,description,valueType)数据
def getdataCenterUserVariables(token=get_token()):
    body = """{"query":"query MyQuery {  dataCenterUserVariables {    id   key   name   description   valueType}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterUserVariables']
    return data_info


# 获取event_variables表(id,key,name,description,valueType)数据
def getdataCenterEventVariables(token=get_token()):
    body = """{"query":"query MyQuery {dataCenterEventVariables {    id   key   name   description   valueType}}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content['dataCenterEventVariables']
    return data_info


# 获取元数据
def getMetaData(token=get_token()):
    body = """{"query":"query MyQuery {dataCenterCustomEvents {    key    name    description  }  dataCenterEventVariables {    key    name    
    valueType    description  }  dataCenterUserVariables {    key    name    valueType    description  }}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content
    return data_info


# 获取绑定事件和关联事件属性
def getBindEvent(token=get_token()):
    body = """{"query":"query MyQuery {  dataCenterCustomEvents {    key    attributes {      key    }  }}","variables":null,"operationName":"MyQuery"}"""
    content = send_graphql_post(token, body)
    data_info = content
    return data_info
