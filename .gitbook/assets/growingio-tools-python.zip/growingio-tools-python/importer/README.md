# GrowingIO Importer
GrowingIO Importer是GrowingIO CDP平台元数据和数据导入工具。

## 入门
有关GrowingIO Importer请访问[GrowingIO官方文档](https://docs.growingio.com/v3/allguide )获取帮助。

## 环境依赖
| |1.0|
|----|----|
|Python|3.6|

## 安装
下载工具包GrowingIO Importer,在importer目录下执行python3 -m pip install -r requirements.txt

## 元数据导入
目前支持如下：
* 创建事件
* 创建事件属性
* 创建用户属性
* 绑定事件与事件属性
* 导出元数据
* 导入元数据

### 使用说明
#### 创建事件
    meta_importer -m create_event \
    --key <事件名> \
    [-n <事件显示名>] \
    [-d <事件描述>] \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-k、--key|必选参数，事件名。仅允许大小写英文、数字、以及下划线，并且不能以数字开头，限长30字符|
|-n、--name|可选参数，事件显示名。默认同事件名，限长30字符|
|-d、--desc|可选参数，事件描述，默认为空。若描述中有空格则需要加双引号|

#### 创建事件属性
    python3 meta_importer.py -m create_event_variables \
                             -k <事件名> \
                             -t <事件属性数据类型> \
                             [-n <事件显示名>] \
                             [-d <事件属性描述>] \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-k、--key|必选参数，事件名。仅允许大小写英文、数字、以及下划线，并且不能以数字开头，限长30字符|
|-t、--type|必选参数，事件属性数据类型。可选值：string/int/double
|-n、--name|可选参数，事件显示名。默认同事件名，限长30字符|
|-d、--desc|可选参数，事件描述，默认为空。若描述中有空格则需要加双引号|

#### 创建用户属性
    python3 meta_importer.py -m create_user_variables \
                             -k <标识符> \
                             -t <用户属性数据类型> \
                             [-n <用户显示名>] \
                             [-d <用户属性描述>] \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-k、--key|必选参数，标识符。仅允许大小写英文、数字、以及下划线，并且不能以数字开头，限长30字符|
|-t、--type|必选参数，可选参数：string/int/date
|-n、--name|可选参数，用户显示名。默认同标识符，限长30字符|
|-d、--desc|可选参数，用户属性描述，默认为空。若描述中有空格则需要加双引号|

#### 绑定事件与事件属性
    python3 meta_importer.py -m bind_event_variables \
                             -k <事件名> \
                             -a <绑定事件属性名> \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-k、--key|必选参数，事件名。若事件不存在则创建，否则更新事件|
|-a、--attr|必选参数，绑定事件属性名。多个属性名使用英文逗号分隔|

#### 导出元数据
    python3 meta_importer.py -m export_meta \
                             -f <文件名> \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-f、--file|必选参数，导出文件名|

#### 导入元数据
    python3 meta_importer.py -m import_meta \
                             -f <文件名> \
|参数|参数说明|
|----|----|
|-m|必选参数，项目名。|
|-f、--file|必选参数，导入文件名|

## 数据导入
目前支持如下：
* 用户属性数据导入
* 用户行为数据导入

### 使用说明
#### 用户属性数据导入
    python3 data_importer.py -m  user_variables \
                             -p  文件路径 \
                             -ds 数据源ID \
                             -f  [CSV|TSV|Json] \
                             -d  [True|False] \
                             -qf " \
                             -sep , \
                             -skh \
                             -attr userId,...
                            
|参数|参数说明|
|----|----|
|-m|必填参数. 用户属性数据导入-user_variables|
|-p|必填参数. 需要导入的数据所在的路径|
|-ds|必填参数. 数据源ID|
|-f|可选参数. 导入数据格式,目前支持JSON,CSV,TSV三种格式.默认值:JSON|
|-d|可选参数. True-导入数据全量校验但不导,false-立即创建导入任务进入导入队列.默认值:True|
|-qf|可选参数. CSV,TSV格式文本限定符.默认值:"|
|-sep|可选参数. CSV,TSV格式文本分割符.默认值:,|
|-skh|可选参数. CSV,TSV格式设置则自动跳过首行,此参数不需要设置值.|
|-attr|可选参数. CSV,TSV格式导入文件的各列按顺序映射到属性名，逗号分隔.userId必须指定|


#### 用户行为数据导入
    python3 data_importer.py -m  events \
                             -p  文件路径 \
                             -ds 数据源ID \
                             -f  [CSV|TSV|Json] \
                             -d  [True|False] \
                             -qf " \
                             -sep , \
                             -skh \
                             -attr userId,... \
                             -s YYYY-MM-DD \
                             -e YYYY-MM-DD
                            
|参数|参数说明|
|----|----|
|-m|必填参数. 用户行为数据导入-events|
|-p|必填参数. 需要导入的数据所在的路径|
|-ds|必填参数. 数据源ID|
|-f|可选参数. 导入数据格式,目前支持JSON,CSV,TSV三种格式.默认值:JSON|
|-d|可选参数. True-导入数据全量校验但不导,false-立即创建导入任务进入导入队列.默认值:True|
|-qf|可选参数. CSV,TSV格式文本限定符.默认值:"|
|-sep|可选参数. CSV,TSV格式文本分割符.默认值:,|
|-skh|可选参数. CSV,TSV格式设置则自动跳过首行,此参数不需要设置值.|
|-attr|可选参数. CSV,TSV格式导入文件的各列按顺序映射到属性名，逗号分隔.userId,event,timestamp必须指定|
|-s|可选参数. 可选参数. 数据起始时间,导入用户行为数据时指定.格式:YYYY-MM-DD|
|-e|可选参数. 可选参数. 数据结束时间,导入用户行为数据时指定.格式:YYYY-MM-DD|