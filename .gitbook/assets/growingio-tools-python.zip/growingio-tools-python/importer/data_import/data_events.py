#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved

import time
import json
import tempfile
import os

from importer.data_import.data_model import EventsCv, EventsJson, DataEvent
from importer.data_import.data_format_util import *
from importer.common import sqlalchemy_util, http_util, common_util
from json.decoder import JSONDecodeError
from importer.common.common_util import encode, get_all_file, remove_file
from importer.common.log_util import logger


ONE_DAY_MILLISECOND = 86400 * 1000      # 1天(24小时)毫秒值


def events_import(args):
    """
       用户行为导入，按数据格式处理
    """
    # Step one: 校验事件数据基础参数，并预处理
    # 1. 校验时间
    event_start = args.get('event_start')
    if event_start is None:
        logger.error("[-s/--event_start]参数值未指定")
        return
    event_end = args.get('event_end')
    if event_end is None:
        logger.error("[-e/--event_end]参数值未指定")
        return
    try:
        event_start = int(time.mktime(time.strptime(event_start, '%Y-%m-%d'))) * 1000
        event_end = int(time.mktime(time.strptime(event_end, '%Y-%m-%d'))) * 1000 + ONE_DAY_MILLISECOND
    except TypeError and ValueError:
        logger.error("[-s/--event_start]或[-e/--event_end]时间参数格式不对,格式为:YYYY-MM-DD")
        return
    # 2. 数据源是否为事件
    ds = args.get('datasource_id')
    if 'HISTORY_EVENT'.__eq__(ds[1]['type']):
        args['datasource_id'] = encode(ds[0])
    else:
        logger.error("数据源不属于用户行为类型")
        return
    # Step one: 按数据格式处理
    f = str(args.get('format'))
    if 'JSON'.__eq__(f):
        events_import_json(
            EventsJson(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                       datasourceId=args.get('datasource_id'), eventStart=event_start, eventEnd=event_end)
        )
    elif 'CSV'.__eq__(f):
        events_import_sv(
            EventsCv(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                     datasourceId=args.get('datasource_id'), attributes=args.get('attributes'), separator=",",
                     skipHeader=args.get('skip_header'), eventStart=event_start, eventEnd=event_end)
        )
    elif 'TSV'.__eq__(f):
        events_import_sv(
            EventsCv(name=args.get('m'), path=args.get('path'), debug=args.get('debug'), format=f,
                     datasourceId=args.get('datasource_id'), attributes=args.get('attributes'), separator='\t',
                     skipHeader=args.get('skip_header'), eventStart=event_start, eventEnd=event_end)
        )


def events_import_sv(eventsCv):
    """
       用户行为导入，CSV/TSV格式数据处理
    """
    # Step 1: 创建临时文件夹，用于存储临时Json文件
    current_tmp_path = tempfile.gettempdir() + '/' + str(int(round(time.time() * 1000)))
    if os.path.exists(current_tmp_path) is False:
        os.makedirs(current_tmp_path)
    logger.debug(f"临时存储Json文件目录：[{current_tmp_path}]")

    try:
        # Step 2: 校验SV数据，并转为Json格式
        n = 0
        for path in eventsCv.path:
            json_file_abs_path = current_tmp_path + '/' + os.path.basename(path).split('.')[0] + '.json'
            res = sv_import_prepare_process(attributes=eventsCv.attributes,
                                            path=path,
                                            skip_header=eventsCv.skipHeader,
                                            separator=eventsCv.separator,
                                            qualifier=eventsCv.qualifier,
                                            json_file_abs_path=json_file_abs_path)
            if res:
                n = n + 1
        # Step 3: 调用Json导入函数:events_import_json
        if n == len(eventsCv.path):
            events_import_json(
                EventsJson(name='events',
                           path=get_all_file(current_tmp_path),
                           debug=eventsCv.debug,
                           format='JSON',
                           eventStart=eventsCv.eventStart,
                           eventEnd=eventsCv.eventEnd,
                           datasourceId=eventsCv.datasourceId)
            )
    finally:
        # Step 4: 清理Json临时文件
        remove_file(current_tmp_path)


# SV格式(CSV、TSV)
def sv_import_prepare_process(attributes, path, skip_header, separator, qualifier, json_file_abs_path):
    """
      1.校验数据基本信息
      2.SV格式数据转换为Json格式导入
    """
    # Step 1: 校验有无attributes,有无重复列名
    if attributes is None:
        logger.error("[-attr/--attributes]参数值不存在")
        return
    cols = str(attributes).split(',')
    duplicate_col = check_sv_col_duplicate(cols)
    if duplicate_col is not None:
        logger.error(f"[-attr/--attributes]出现重复列值[{duplicate_col}]")
        return
    cstm_keys = sqlalchemy_util.get_custom_event_attributes_view()
    # Json文件临时存储
    with open(path, 'r', encoding='utf8') as f:
        with open(json_file_abs_path, 'w') as wf:
            line = f.readline().replace('\n', '').replace('\\t', '\t')
            # Step 2: 校验数据header列是否一致，数量和顺序
            if skip_header is True:
                if check_sv_header_col_count(cols, line.split(separator)) is False:
                    logger.error(f"[-attr/--attributes]参数值列与导入文件[{path}]的列数不一致")
                    return
                if check_sv_header_col_order(cols, line.split(separator)) is False:
                    logger.error(f"[-attr/--attributes]参数值列与导入文件[{path}]的列顺序不一致")
                    return
                line = f.readline().replace('\n', '').replace('\\t', '\t')
            # Step 3: 校验数据列是否一致
            while line != '':
                values = common_util.split_str(line, separator, qualifier)
                if len(cols) != len(values):
                    logger.error(f"文件[{path}]数据[{line}], 列数与文件头部列数不一致")
                    return
                # Step 4: 转换为JSON格式
                col_value = {}
                for col, value in tuple(zip(cols, values)):
                    if col != '':
                        col_value[col] = value
                if col_value['event'] in cstm_keys:
                    attrs = {}
                    for key in col_value:
                        if key in cstm_keys[col_value['event']] and 'userId'.__eq__(key) is False \
                                                                and 'event'.__eq__(key) is False \
                                                                and 'timestamp'.__eq__(key) is False:
                            attrs[key] = col_value[key]
                    data_event = DataEvent(userId=col_value['userId'], event=col_value['event'],
                                           timestamp=col_value['timestamp'], attrs=attrs)
                    wf.write(json.dumps(data_event.__dict__, ensure_ascii=False))
                    wf.write('\n')
                else:
                    logger.error(
                        f"文件[{path}]数据[{col_value.__str__()}], "
                        f"自定义事件属性[{str(col_value['event'])}]在GIO平台未定义或未绑定事件属性"
                    )
                    return
                line = f.readline().replace('\n', '').replace('\\t', '\t')
    return True


def events_import_json(eventsJson):
    """
       用户行为导入，Json格式数据处理
    """
    # Step 1: 执行Debug
    if eventsJson.debug:
        if events_debug_process(eventsJson.path, eventsJson.eventStart, eventsJson.eventEnd) is not True:
            logger.error("Debug校验未通过")
            return
    # Step 2: 创建导入任务
    job_info = create_task(eventsJson.eventStart, eventsJson.eventEnd, eventsJson.datasourceId)
    logger.info(f"创建导入任务: {job_info}")
    # Step 3: 上传数据到FTP
    put_file(eventsJson.path, job_info['argument']['directory'])
    # Step 4: 启动导入任务
    trigger_job(job_info['id'])


def trigger_job(id):
    body = '''{
      "operationName":"executeJob",
      "variables":{"id":"%s"},
      "query":"mutation executeJob($id: HashId!) {  
        executeJob(id: $id) {
            id    
            stage    
            __typename  
        }
      }"
    }''' % id
    http_util.send_graphql_post(http_util.get_token(), body)


def create_task(start, end, ds):
    body = '''{
      "operationName": "createEventImportJob",
      "variables": {
        "tunnelId": "%s",
        "timeRange": "abs:%s,%s"
      },
      "query": "mutation createEventImportJob($tunnelId: HashId!, $timeRange: String) {
        createEventImportJob(tunnelId: $tunnelId, timeRange: $timeRange) {
          id
          name
          argument {
            directory
            __typename
          }
          __typename
          }
      }"
    }''' % (ds, start, end)
    resp = http_util.send_graphql_post(http_util.get_token(), body)
    return resp['createEventImportJob']


def events_debug_process(paths, eventStart, eventEnd):
    """
       用户行为导入Debug
       1、校验文件的数据内容合法性, 是否缺失必要字段(userId,event,timestamp)
       2、校验文件的数据时间范围合法性
       3、校验自定义事件在GIO平台是否定义
    """
    cstm_keys = sqlalchemy_util.get_custom_event_attributes_view()
    cstm_attr_keys = sqlalchemy_util.get_event_attributes_activated_keys()
    count = 0
    for path in paths:
        with open(path, 'r', encoding='utf8') as f:
            line = f.readline().replace('\n', '')
            while line.strip() != '':
                count = count + 1
                try:
                    j_dict = json.loads(line)
                    # 1.1 userId
                    if 'userId' not in j_dict:
                        logger.error(f"文件[{path}]数据[{line}], userId不存在")
                        return
                    # 1.2 event
                    if 'event' not in j_dict:
                        logger.error(f"文件[{path}]数据[{line}], event不存在")
                        return
                    # 1.3 timestamp
                    if 'timestamp' not in j_dict:
                        logger.error(f"文件[{path}]数据[{line}], timestamp不存在")
                        return
                    if isinstance(j_dict['timestamp'], int) is False:
                        logger.error(f"文件[{path}]数据[{line}], timestamp数据格式不对")
                        return
                    # 2 timestamp
                    if j_dict['timestamp'] < eventStart or j_dict['timestamp'] >= eventEnd:
                        logger.error(f"文件[{path}]数据[{line}], timestamp时间范围不合法")
                        return
                    # 3 事件
                    var_keys = cstm_keys.get(j_dict['event'])
                    # 事件key
                    if var_keys is None:
                        logger.error(f"文件[{path}]数据[{line}], 自定义事件[{j_dict['event']}]在GIO平台未定义或未绑定事件属性")
                        return
                    for attr in j_dict['attrs']:
                        # 事件属性
                        if attr not in cstm_attr_keys:
                            logger.error(f"文件[{path}]数据[{line}], 自定义事件属性[{attr}]在GIO平台未定义")
                            return
                        # 事件与属性
                        if attr not in var_keys:
                            logger.error(f"文件[{path}]数据[{line}], 自定义事件属性[{attr}]未与自定义事件[{j_dict['event']}]绑定")
                            return
                except JSONDecodeError:
                    logger.error(f"文件[{path}]数据[{line}]非JSON格式")
                    return
                line = f.readline().replace('\n', '')
    logger.info(f"本次共导入[{count}]行数据")
    return True
