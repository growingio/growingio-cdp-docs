#!/bin/env python3
# -*- coding: UTF-8 -*-
import os
import subprocess

import requests

import urllib3
import json
import logging

from importer.common.config_util import ApiConfig, SaasConfig

http = urllib3.PoolManager()


def get_token():
    """登录获取身份令牌"""
    cxt = getExtensionClient()
    payload = {'grant_type': cxt['authorizedGrantTypes'][0], 'client_id': cxt['clientId'],
               'client_secret': cxt['clientSecret'], 'scope': cxt['scope'][0], 'username': ApiConfig.username,
               'password': ApiConfig.password}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    response = requests.post(ApiConfig.oauth2_uri + "/oauth/token", headers=headers, data=payload)
    if response.status_code == 200:
        content = json.loads(response.content)
        return content['access_token']
    else:
        logging.error("获取登录身份令牌失败，请检查配置{}".format(payload))
        exit(-1)


def send_graphql_post(token, body):
    """
     graphql post请求
    :param token: 登录身份令牌
    :param body: 请求graphql body
    :return: 响应数据
    """
    headers = {'Content-Type': 'application/json', 'Authorization': token}
    r = requests.post(ApiConfig.oauth2_uri + "/graphql", headers=headers, data=body)
    if r.status_code == 200:
        content = json.loads(r.content)
        if content.keys().__contains__("data") is True:
            return content['data']
        else:
            logging.error('Graphql请求错误,{}'.format(content['errors']))
            exit(-1)
    else:
        re = input("Graphql请求超时或失败，是否重新请求，请输入yes/no:")
        if str(re).lower() == 'yes':
            send_graphql_post(token, body)
        else:
            return


def send_rest_get(url, params):
    """
     http post请求
    :param url: 请求url
    :param params: 请求参数
    :return: 响应数据
    """
    # headers = {'Content-Type': 'application/json', 'Authorization': SaasConfig.token}
    headers = {'Content-Type': 'application/json'}
    r = requests.get(SaasConfig.uri + url, headers=headers, params=params)
    if r.status_code == 200:
        content = json.loads(r.text)
        return content


def put_file_ftp(file_list, target_directory):
    headers = {'Authorization': 'Bearer ' + get_token()}
    for file in file_list:
        file_splits = file.split('/')
        simple_name = file_splits[len(file_splits) - 1]
        with open(file, 'rb') as fp:
            file_data = fp.read()
            http.request('POST', ApiConfig.oauth2_uri + '/upload', headers=headers,
                         fields={'file': (simple_name, file_data), 'path': target_directory})


def put_file_hdfs(file_list, target_directory):
    for file in file_list:
        os.system(f"hdfs dfs -put {file} {target_directory}")


def getExtensionClient():
    headers = {'Content-Type': 'application/json'}
    r = requests.get(ApiConfig.oauth2_uri + '/chrome_extension_client', headers=headers)
    if r.status_code == 200:
        content = json.loads(r.text)
        return content


