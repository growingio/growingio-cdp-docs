#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved


class ImportBase:
    """
      Import Base
    """
    def __init__(self, name, path, debug, format, datasourceId):
        self.name = name
        self.path = path
        self.debug = debug
        self.format = format
        self.datasourceId = datasourceId


class SVBase:
    """
      SV Base
    """
    def __init__(self, skipHeader, separator, qualifier='"'):
        self.qualifier = qualifier
        self.separator = separator
        self.skipHeader = skipHeader


class UserVariables(ImportBase):
    """
      用户属性
    """
    def __init__(self, name, path, debug, format, datasourceId):
        ImportBase.__init__(self, name, path, debug, format, datasourceId)


class UserVariablesJson(UserVariables):
    """
      用户属性-Josn格式
    """
    def __init__(self, name, path, format, datasourceId, debug=True):
        UserVariables.__init__(self, name, path, debug, format, datasourceId)


class UserVariablesSv(UserVariables, SVBase):
    """
      用户属性-CSV/TSV格式
    """
    def __init__(self, name, path, debug, format, datasourceId, attributes, skipHeader, separator, qualifier='"'):
        UserVariables.__init__(self, name, path, debug, format, datasourceId)
        SVBase.__init__(self, skipHeader, separator, qualifier)
        self.attributes = attributes


class Events(ImportBase):
    """
      用户行为
    """
    def __init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd):
        ImportBase.__init__(self, name, path, debug, format, datasourceId)
        self.eventStart = eventStart
        self.eventEnd = eventEnd


class EventsJson(Events):
    """
      用户行为-Josn格式
    """
    def __init__(self, name, path, format, datasourceId, eventStart, eventEnd, debug=True):
        Events.__init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd)


class EventsCv(Events, SVBase):
    """
      用户行为-CSV/TSV格式
    """
    def __init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd, attributes, skipHeader, separator, qualifier='"'):
        Events.__init__(self, name, path, debug, format, datasourceId, eventStart, eventEnd)
        SVBase.__init__(self, skipHeader, separator, qualifier)
        self.attributes = attributes


class DataEvent:
    """
      用户行为大数据规定格式
    """
    def __init__(self, userId, event, timestamp, attrs, userKey=''):
        self.userId = userId
        self.event = event
        self.userKey = userKey
        self.timestamp = timestamp
        self.attrs = attrs


class DataUser:
    """
      用户属性大数据规定格式
    """
    def __init__(self, userId, attrs):
        self.userId = userId
        self.attrs = attrs
