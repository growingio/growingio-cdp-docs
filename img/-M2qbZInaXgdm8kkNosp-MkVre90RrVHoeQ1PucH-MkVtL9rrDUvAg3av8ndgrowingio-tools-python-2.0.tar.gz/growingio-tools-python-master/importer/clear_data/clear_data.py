import json

import requests

from importer.common.config_util import ApiConfig
from importer.common.http_util import get_token
from importer.common.log_util import logger
import tempfile
import time
import os

from importer.meta.data_center import updateClearUserJobStatus, getClearUsers


def clearUserData(execute):
    if str(execute).upper() == 'TRUE':
        users = getClearUsers()
        for user in users:
            assert updateClearUserJobStatus(user) == 'RUNNING'
        headers = {'Content-Type': 'application/json', 'Authorization': get_token()}
        ftpPath = '/clearuser/' + str(int(round(time.time() * 1000)))
        body = {'pipelineDefinitionId': 'ClearUserPipeline', 'identity': 'gio', 'conf': {'$ftpPath': ftpPath}}
        r = requests.post(ApiConfig.oauth2_uri + '/data-server/scheduler/pipeline/running', headers=headers,
                          data=json.dumps(body))
        if r.status_code == 200 and json.loads(r.content)['state'] == 'running':
            logger.info("提交清理用户删除离线任务")
            logger.info("待删除用户数据存放FTP位置为:{}".format('/ftp/admin' + ftpPath))
    elif str(execute).upper() == 'FALSE':
        users = getClearUsers()
        for user in users:
            assert updateClearUserJobStatus(user) == 'RUNNING'
        logger.info("等待天任务清理用户删除任务")
        logger.info("待删除用户数据将存放FTP位置为:{}".format('/ftp/admin/clearuser'))
