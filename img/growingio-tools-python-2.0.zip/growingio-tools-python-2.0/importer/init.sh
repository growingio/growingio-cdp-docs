#!/bin/bash
yum install -y gcc-c++
yum install -y libevent-devel
yum install -y python3-devel
yum install -y python-devel
yum install -y gcc-c++ python-devel.x86_64 cyrus-sasl-devel.x86_64

python3 -m pip install -r requirements.txt