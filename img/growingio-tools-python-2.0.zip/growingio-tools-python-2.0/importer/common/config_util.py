#!/bin/env python3
# -*- coding: UTF-8 -*-

import os
import pathlib
from configparser import ConfigParser

config = ConfigParser()
config.read(os.path.abspath(str(pathlib.Path(os.path.abspath(__file__)).parent.parent) + "/conf.cfg"), encoding="UTF-8")

class ApiConfig:
    """A ApiConfig Class"""
    oauth2_uri = config['API']['oauth2_uri']
    username = config['API']['username']
    password = config['API']['password']


class BaseConfig:
    """A BaseConfig Class"""
    timezone = 'Asia/Shanghai'


class FTPConfig:
    host = ''
    user = ''
    password = ''
    port = ''


class SaasConfig:
    uri = config['SAAS']['saas_uri']
    token = config['SAAS']['saas_token']
    uid = config['SAAS']['saas_uid']
