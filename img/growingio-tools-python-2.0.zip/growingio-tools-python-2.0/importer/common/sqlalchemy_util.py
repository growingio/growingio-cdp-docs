#!/bin/env python3
# -*- coding: UTF-8 -*-

from sqlalchemy import *
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql.functions import now
from importer.common.config_util import BaseConfig

"""
 Class Model
"""
# 创建对象的基类:
Base = declarative_base()


class UserVariables(Base):
    """
     Table: events.user_variables
    """
    __tablename__ = 'user_variables'
    id = Column(Integer, primary_key=True)
    data_center_id = Column(Integer, nullable=False)
    ai = Column(Text, nullable=False)
    key = Column(Text, nullable=False)
    name = Column(Text, nullable=False)
    description = Column(Text)
    is_system = Column(Boolean, nullable=False, default=False)
    status = Column(Text, nullable=False, default='activated')
    attribution = Column(Text)
    creator_id = Column(Integer, nullable=False)
    created_at = Column(TIMESTAMP, nullable=False)
    updater_id = Column(Integer)
    updated_at = Column(TIMESTAMP, nullable=False, default=now())
    is_high_cardinality = Column(Boolean, default=False)
    value_type = Column(Text, nullable=False)


class CustomEvents(Base):
    """
     Table: events.custom_events
    """
    __tablename__ = 'custom_events'
    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, nullable=False)
    name = Column(Text, nullable=False)
    description = Column(Text)
    value_type = Column(Text, nullable=False)
    key = Column(Text, nullable=False)
    ai = Column(Text, nullable=False)
    realtime = Column(Boolean, nullable=False, default=False)
    business_type = Column(Text)
    is_system = Column(Boolean, nullable=False, default=False)
    status = Column(Text, nullable=False, default='activated')
    creator_id = Column(Integer, nullable=False)
    created_at = Column(TIMESTAMP, nullable=False)
    updater_id = Column(Integer)
    updated_at = Column(TIMESTAMP, nullable=False, default=now())
    detected_at = Column(TIMESTAMP)


class EventVariables(Base):
    """
     Table: events.event_variables
    """
    __tablename__ = 'event_variables'
    id = Column(Integer, primary_key=True)
    data_center_id = Column(Integer, nullable=False)
    ai = Column(Text, nullable=False)
    key = Column(Text, nullable=False)
    name = Column(Text, nullable=False)
    description = Column(Text)
    mapping_id = Column(Integer)
    value_type = Column(Text, nullable=False)
    is_system = Column(Boolean, nullable=False, default=False)
    status = Column(Text, nullable=False, default='activated')
    creator_id = Column(Integer, nullable=False)
    created_at = Column(TIMESTAMP, nullable=False)
    updater_id = Column(Integer)
    updated_at = Column(TIMESTAMP, nullable=False, default=now())
    is_high_cardinality = Column(Boolean, default=False)


class CustomEventAttributes(Base):
    """
     Table: events.custom_event_attributes
    """
    __tablename__ = 'custom_event_attributes'
    id = Column(Integer, primary_key=True)
    data_center_id = Column(Integer, nullable=False)
    event_id = Column(Integer, nullable=False)
    attribute_id = Column(Integer, nullable=False)
    associated_at = Column(TIMESTAMP, nullable=False, default=now())


class CustomEventAttributesView(Base):
    """
     View: events.custom_events LEFT JOIN  events.custom_event_attributes LEFT JOIN events.event_variables
    """
    __tablename__ = 'custom_event_attributes_view'
    id = Column(Integer, primary_key=True)
    data_center_id = Column(Integer, nullable=False)
    event_id = Column(Integer, nullable=False)
    attribute_id = Column(Integer, nullable=False)
    associated_at = Column(TIMESTAMP, nullable=False, default=now())


class Tunnels(Base):
    """
     Table: cdp.tunnels
    """
    __tablename__ = 'tunnels'
    id = Column(Integer, primary_key=True)
    data_center_id = Column(Integer, nullable=False)
    name = Column(Text, nullable=False)
    type = Column(Text, nullable=False)
    config = Column(JSON)
    status = Column(Text, nullable=False)
    description = Column(Text, nullable=False)
    creator_id = Column(Integer, nullable=False)
    created_at = Column(TIMESTAMP, nullable=False)
    updater_id = Column(Integer)
    updated_at = Column(TIMESTAMP, nullable=False, default=now())
    key = Column(Text, nullable=False)
    config_clazz = Column(Text)


"""
 DATABASE: events
"""
event_engine = create_engine('')
event_session = sessionmaker(bind=event_engine)()


def get_event_attributes_activated_keys():
    """
        [event_attributes1,...]
    """
    keys = event_session.query(EventVariables.key).filter(EventVariables.ai == BaseConfig.account_id) \
        .filter(EventVariables.status == 'activated') \
        .all()
    result = []
    for key in keys:
        result.append(key[0])
    return result


def get_custom_event_attributes_view():
    """
        event_key:[event_attributes1,...]
    """
    custom_event_attributes_view = event_session \
        .query(CustomEvents.ai, CustomEvents.id, CustomEvents.key, EventVariables.id, EventVariables.key,
               EventVariables.value_type) \
        .select_from(CustomEvents) \
        .outerjoin(CustomEventAttributes, CustomEvents.id == CustomEventAttributes.event_id) \
        .outerjoin(EventVariables, EventVariables.id == CustomEventAttributes.attribute_id) \
        .filter(CustomEvents.ai == BaseConfig.account_id) \
        .filter(CustomEvents.status == 'activated') \
        .filter(EventVariables.ai == BaseConfig.account_id) \
        .filter(EventVariables.status == 'activated') \
        .all()
    result = {}
    for view in custom_event_attributes_view:
        var = result.get(view[2])
        if var is None:
            result[view[2]] = [view[4]]
        else:
            var.append(view[4])
    return result


def get_user_variables_activated_key():
    keys = event_session.query(UserVariables.key).filter(UserVariables.ai == BaseConfig.account_id) \
        .filter(UserVariables.status == 'activated') \
        .all()
    result = []
    for key in keys:
        result.append(key[0])
    return result


def count(object, filter):
    return event_session.query(object).filter(filter).count()


def filterone(object, filter):
    return event_session.query(object).filter(filter).first()


"""
 DATABASE: cdp
"""
cdp_engine = create_engine('')
cdp_session = sessionmaker(bind=cdp_engine)()


def get_tunnel_id_by_key(key):
    """
        获取key对应数据主键
    """
    ids = cdp_session.query(Tunnels.id, Tunnels.config)\
        .filter(Tunnels.key == key)\
        .filter(Tunnels.status == 'activated')\
        .all()
    if ids is not None and len(ids) > 0:
        return ids[0]


"""
 DATABASE: other
"""
