#!/bin/env python3
# -*- coding: UTF-8 -*-

# Copyright (c) 2020 growingio.com, Inc.  All Rights Reserved
import argparse
import os
import pathlib
import sys

sys.path.append(str(pathlib.Path(os.path.abspath(__file__)).parent.parent))
from importer.meta.meta_create import *
from importer.clear_data.clear_data import clearUserData


def parse_args():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('-m',
                        help='必填参数. 创建事件-clear_users',
                        required=True, metavar="")
    parser.add_argument('-n','--now',
                        help='可选参数. True-立即执行离线任务,false-天任务执行清理任务',
                        required=True)
    args = parser.parse_args()
    return args.__dict__


def main():
    args = parse_args()
    m = args.get("m")
    if 'clear_users'.__eq__(m):
        clearUserData(args.get("now"))
    else:
        logging.error("请确认填写项目名！")
        exit(-1)


if __name__ == '__main__':
    main()
