import json
import os
import tempfile
import time

from pyhive.exc import OperationalError
from importer.common.common_util import get_all_file, remove_file, hive_connect, getVariables
from importer.common.log_util import logger
from importer.data_import.data_events import events_import_json
from importer.data_import.data_model import EventsJson, DataEvent, DataUser, UserVariablesJson
from importer.data_import.data_user_variable import user_variables_import_json
from importer.meta.data_center import getBindEvent, getdataCenterUserVariables


def event_hive_import(args, start, end):
    """
       行为数据导入，HIVE数据源
    """
    try:
        conn = hive_connect(host=args.get('host'),
                            port=int(args.get('port')),
                            user=args.get('user')
                            )
    except TypeError:
        logger.error("HIVE连接失败。")
        exit(-1)
    cursor = conn.cursor()
    try:
        sql = args.get('sql')
        cursor.execute(sql)
        logger.info(sql)
    except OperationalError:
        logger.error("请检查SQL语句")
        exit(-1)
    desc = cursor.description
    desc_list = []
    for d in desc:
        desc_list.append(d[0])
    if 'userId' not in desc_list or 'event' not in desc_list or 'timestamp' not in desc_list:
        logger.error("userId或event或timestamp字段不存在")
        exit(-1)

    current_tmp_path = tempfile.gettempdir() + '/' + str(int(round(time.time() * 1000)))
    if os.path.exists(current_tmp_path) is False:
        os.makedirs(current_tmp_path)
    logger.debug(f"临时存储Json文件目录：[{current_tmp_path}]")
    json_file_abs_path = current_tmp_path + '/' + 'tmp_events.json'
    event = getBindEvent()
    res = {}
    for i in event['dataCenterCustomEvents']:
        list = []
        for a in i['attributes']:
            list.append(a['key'])
        res[i['key']] = list
    try:
        wf = open(json_file_abs_path, 'w')
        cnt = 0
        while True:
            cnt += 1
            data = cursor.fetchmany(size=args.get('batch'))
            if len(data) == 0 and cnt == 1:
                logger.error("数据为空")
                exit(-1)
            elif len(data) == 0 and cnt > 1:
                events_import_json(
                    EventsJson(name='events',
                               path=get_all_file(current_tmp_path),
                               format='JSON',
                               debug=False,
                               eventStart=start,
                               eventEnd=end,
                               datasourceId=args.get('datasource_id'))
                )
                break
            else:
                json_list = []
                for row in data:
                    res = {}
                    var = {}
                    for a in range(len(row)):
                        if desc_list[a] == 'userId' or desc_list[a] == 'event' or desc_list[a] == 'timestamp':
                            res[desc_list[a]] = row[a]
                        else:
                            var[desc_list[a]] = row[a]
                    res['attrs'] = var
                    json_list.append(res)
                for json_str in json_list:
                    if json_str['event'] in res:
                        for key in json_str['attrs']:
                            if key not in res[json_str['event']]:
                                logger.error(f"自定义事件属性[{key}]在GIO平台未定义或未绑定事件属性")
                                exit(-1)
                        data_event = DataEvent(userId=json_str['userId'], event=json_str['event'],
                                               timestamp=json_str['timestamp'], attrs=json_str['attrs'])
                        wf.write(json.dumps(data_event.__dict__, ensure_ascii=False))
                        wf.write('\n')
                    else:
                        logger.error(f"事件[{json_str['event']}]在GIO平台未定义或者未绑定属性")
                        exit(-1)
    finally:
        remove_file(current_tmp_path)


def user_hive_import(args):
    """
       用户属性导入，HIVE数据源
    """
    try:
        conn = hive_connect(host=args.get('host'),
                            port=int(args.get('port')),
                            user=args.get('user'))
    except TypeError:
        logger.error("HIVE连接失败。")
        exit(-1)
    cursor = conn.cursor()
    try:
        sql = args.get('sql')
        cursor.execute(sql)
        logger.info(sql)
    except OperationalError:
        logger.error("请检查SQL语句")
        exit(-1)
    desc = cursor.description
    desc_list = []
    for d in desc:
        desc_list.append(d[0])
    if 'userId' not in desc_list:
        logger.error("userId字段不存在")
        exit(-1)

    current_tmp_path = tempfile.gettempdir() + '/' + str(int(round(time.time() * 1000)))
    if os.path.exists(current_tmp_path) is False:
        os.makedirs(current_tmp_path)
    logger.debug(f"临时存储Json文件目录：[{current_tmp_path}]")
    keys = getVariables(getdataCenterUserVariables())
    json_file_abs_path = current_tmp_path + '/' + 'tmp_user.json'
    try:
        wf = open(json_file_abs_path, 'w')
        cnt = 0
        while True:
            cnt += 1
            data = cursor.fetchmany(size=args.get('batch'))
            if len(data) == 0 and cnt == 1:
                logger.error("数据为空")
                exit(-1)
            elif len(data) == 0 and cnt > 1:
                user_variables_import_json(
                    UserVariablesJson(name='user_variables',
                                      path=get_all_file(current_tmp_path),
                                      debug=False,
                                      format='JSON',
                                      datasourceId=args.get('datasource_id'))
                )
                break
            else:
                json_list = []
                for row in data:
                    res = {}
                    var = {}
                    for a in range(len(row)):
                        if desc_list[a] == 'userId':
                            res[desc_list[a]] = row[a]
                        else:
                            var[desc_list[a]] = row[a]
                    res['attrs'] = var
                    json_list.append(res)
                for json_str in json_list:
                    for key in json_str['attrs']:
                        if key not in keys and key.startswith("$") is False:
                            logger.error("用户属性{}在GIO平台未定义".format(key))
                            exit(-1)
                    data_event = DataUser(userId=json_str['userId'], attrs=json_str['attrs'])
                    wf.write(json.dumps(data_event.__dict__, ensure_ascii=False))
                    wf.write('\n')
    finally:
        remove_file(current_tmp_path)
